Generate Test/Training dataset using genLetters.py
Generate CNN-Model using CNN.py
Copy I AM printed dataset into parent folder (or change folder in main.py)
Process whole dataset using main.py